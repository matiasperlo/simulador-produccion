#ifndef SIMULADOR_H
#define SIMULADOR_H


class Simulador
{
public:
    Simulador();
};

#endif // SIMULADOR_H
