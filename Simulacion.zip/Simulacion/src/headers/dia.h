#ifndef DIA_H
#define DIA_H


class Dia
{


public:
    Dia();
};

#endif // DIA_H
