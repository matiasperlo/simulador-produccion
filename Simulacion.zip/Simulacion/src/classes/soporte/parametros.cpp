#include "../../headers/parametros.h"

Parametros::Parametros()
{

}
