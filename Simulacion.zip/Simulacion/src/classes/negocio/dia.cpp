#include "../../headers/dia.h"

Dia::Dia()
{

}


