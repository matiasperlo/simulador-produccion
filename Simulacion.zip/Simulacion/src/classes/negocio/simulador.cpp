#include "../../headers/simulador.h"

Simulador::Simulador()
{

}
