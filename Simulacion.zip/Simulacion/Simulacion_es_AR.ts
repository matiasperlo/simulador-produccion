<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_AR">
<context>
    <name>Form</name>
    <message>
        <location filename="src/ui/form.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="src/ui/mainwindow.ui" line="35"/>
        <source>Simulacion de Produccion Anual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="115"/>
        <source>Grupo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="120"/>
        <source>Campo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="125"/>
        <location filename="src/ui/mainwindow.ui" line="300"/>
        <location filename="src/ui/mainwindow.ui" line="489"/>
        <source>año</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="130"/>
        <location filename="src/ui/mainwindow.ui" line="305"/>
        <location filename="src/ui/mainwindow.ui" line="494"/>
        <source>rnd clima 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="135"/>
        <location filename="src/ui/mainwindow.ui" line="310"/>
        <location filename="src/ui/mainwindow.ui" line="499"/>
        <source>clima dia 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="140"/>
        <location filename="src/ui/mainwindow.ui" line="315"/>
        <location filename="src/ui/mainwindow.ui" line="504"/>
        <source>rnd clima 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="145"/>
        <location filename="src/ui/mainwindow.ui" line="320"/>
        <location filename="src/ui/mainwindow.ui" line="509"/>
        <source>clima dia 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="150"/>
        <location filename="src/ui/mainwindow.ui" line="325"/>
        <location filename="src/ui/mainwindow.ui" line="514"/>
        <source>rnd clima 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="155"/>
        <location filename="src/ui/mainwindow.ui" line="330"/>
        <location filename="src/ui/mainwindow.ui" line="519"/>
        <source>clima dia 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="160"/>
        <location filename="src/ui/mainwindow.ui" line="335"/>
        <location filename="src/ui/mainwindow.ui" line="524"/>
        <source>rnd clima 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="165"/>
        <location filename="src/ui/mainwindow.ui" line="340"/>
        <location filename="src/ui/mainwindow.ui" line="529"/>
        <source>clima dia 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="170"/>
        <location filename="src/ui/mainwindow.ui" line="345"/>
        <location filename="src/ui/mainwindow.ui" line="534"/>
        <source>rnd clima 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="175"/>
        <location filename="src/ui/mainwindow.ui" line="350"/>
        <location filename="src/ui/mainwindow.ui" line="539"/>
        <source>clima dia 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="180"/>
        <location filename="src/ui/mainwindow.ui" line="355"/>
        <location filename="src/ui/mainwindow.ui" line="544"/>
        <source>rnd clima 6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="185"/>
        <location filename="src/ui/mainwindow.ui" line="360"/>
        <location filename="src/ui/mainwindow.ui" line="549"/>
        <source>clima dia 6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="190"/>
        <location filename="src/ui/mainwindow.ui" line="365"/>
        <location filename="src/ui/mainwindow.ui" line="554"/>
        <source>rnd clima 7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="195"/>
        <location filename="src/ui/mainwindow.ui" line="370"/>
        <location filename="src/ui/mainwindow.ui" line="559"/>
        <source>clima dia 7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="200"/>
        <location filename="src/ui/mainwindow.ui" line="375"/>
        <location filename="src/ui/mainwindow.ui" line="564"/>
        <source>rnd clima 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="205"/>
        <location filename="src/ui/mainwindow.ui" line="380"/>
        <location filename="src/ui/mainwindow.ui" line="569"/>
        <source>clima dia 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="210"/>
        <location filename="src/ui/mainwindow.ui" line="385"/>
        <location filename="src/ui/mainwindow.ui" line="574"/>
        <source>rnd clima 9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="215"/>
        <location filename="src/ui/mainwindow.ui" line="390"/>
        <location filename="src/ui/mainwindow.ui" line="579"/>
        <source>clima dia 9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="220"/>
        <location filename="src/ui/mainwindow.ui" line="395"/>
        <location filename="src/ui/mainwindow.ui" line="584"/>
        <source>rnd clima 10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="225"/>
        <location filename="src/ui/mainwindow.ui" line="400"/>
        <location filename="src/ui/mainwindow.ui" line="589"/>
        <source>clima dia 10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="230"/>
        <location filename="src/ui/mainwindow.ui" line="405"/>
        <location filename="src/ui/mainwindow.ui" line="594"/>
        <source>dias soleados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="235"/>
        <location filename="src/ui/mainwindow.ui" line="410"/>
        <location filename="src/ui/mainwindow.ui" line="599"/>
        <source>dias lluviosos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="240"/>
        <location filename="src/ui/mainwindow.ui" line="415"/>
        <location filename="src/ui/mainwindow.ui" line="604"/>
        <source>dias nublados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="245"/>
        <location filename="src/ui/mainwindow.ui" line="420"/>
        <location filename="src/ui/mainwindow.ui" line="609"/>
        <source>rnd tardanza</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="250"/>
        <location filename="src/ui/mainwindow.ui" line="425"/>
        <location filename="src/ui/mainwindow.ui" line="614"/>
        <source>dias tardanza</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="255"/>
        <location filename="src/ui/mainwindow.ui" line="430"/>
        <location filename="src/ui/mainwindow.ui" line="619"/>
        <source>produccion anual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="260"/>
        <location filename="src/ui/mainwindow.ui" line="435"/>
        <location filename="src/ui/mainwindow.ui" line="624"/>
        <source>produccion anual ac</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="270"/>
        <source>clima primeros 10 dias</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="275"/>
        <source>total dias por clima</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="285"/>
        <source>tardanza fertilizante</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="642"/>
        <source>Ir A:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="671"/>
        <source>Ir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="678"/>
        <source>toolBar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="700"/>
        <source>Generar Simulacion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="709"/>
        <source>Configurar Parametros</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="718"/>
        <source>LimpiarContenido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainwindow.ui" line="727"/>
        <source>Sobre El Ejercicio</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Params</name>
    <message>
        <location filename="src/ui/params.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
